import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import json
import os
import wave
import shutil
import subprocess
import threading
import time
import struct

import fluidsynth


APP_NAME = "SuperCoolMusicCreator"
VERSION = "0.5"

SOUNDFONT = "default.sf2"

SAMPLE_RATE = 44100
PPQ = 480

CELL_W = 32
CELL_H = 22
MAX_BEATS = 64


NOTES = [
    ("C5", 72),
    ("B4", 71),
    ("A#4", 70),
    ("A4", 69),
    ("G#4", 68),
    ("G4", 67),
    ("F#4", 66),
    ("F4", 65),
    ("E4", 64),
    ("D#4", 63),
    ("D4", 62),
    ("C#4", 61),
    ("C4", 60),
    ("B3", 59),
    ("A#3", 58),
    ("A3", 57),
    ("G#3", 56),
    ("G3", 55),
    ("F#3", 54),
    ("F3", 53),
    ("E3", 52),
    ("D#3", 51),
    ("D3", 50),
    ("C#3", 49),
    ("C3", 48),
]


INSTRUMENTS = [
    "Acoustic Grand Piano",
    "Bright Acoustic Piano",
    "Electric Piano",
    "Honky-tonk Piano",
    "Electric Piano 1",
    "Electric Piano 2",
    "Harpsichord",
    "Clavinet",
    "Celesta",
    "Glockenspiel",
    "Music Box",
    "Vibraphone",
    "Marimba",
    "Xylophone",
    "Drawbar Organ",
    "Percussive Organ",
    "Rock Organ",
    "Church Organ",
    "Nylon Guitar",
    "Steel Guitar",
    "Electric Guitar",
    "Acoustic Bass",
    "Electric Bass",
    "Violin",
    "Cello",
    "Trumpet",
    "Trombone",
    "French Horn",
    "Soprano Sax",
    "Alto Sax",
    "Tenor Sax",
    "Flute",
    "Synth Lead",
    "Synth Pad",
    "Choir",
    "Orchestra Hit",
    "Applause",
]


class SuperCoolMusicCreator:

    def __init__(self, root):

        self.root = root

        self.root.title(
            f"{APP_NAME} v{VERSION}"
        )

        self.root.geometry(
            "1250x800"
        )

        self.bpm = tk.IntVar(
            value=120
        )

        self.instrument = tk.IntVar(
            value=0
        )

        self.sections = {}

        self.section_counter = 0

        self.current_section = None

        self.playlist = []

        self.playing = False
        self.stop_requested = False

        self.fs = None
        self.sfid = None
        self.synth_ready = False

        self.setup_fluid()

        self.build_ui()

        self.create_section()

        self.root.protocol(
            "WM_DELETE_WINDOW",
            self.close
        )

    # =========================================================
    # FLUIDSYNTH
    # =========================================================

    def setup_fluid(self):

        try:

            self.fs = fluidsynth.Synth(
                samplerate=SAMPLE_RATE
            )

            self.fs.start()

            sf_path = os.path.join(
                os.path.dirname(
                    os.path.abspath(__file__)
                ),
                SOUNDFONT
            )

            if not os.path.exists(sf_path):

                raise FileNotFoundError(
                    f"Не найден {SOUNDFONT}"
                )

            self.sfid = self.fs.sfload(
                sf_path
            )

            self.fs.program_select(
                0,
                self.sfid,
                0,
                0
            )

            self.synth_ready = True

        except Exception as e:

            self.synth_ready = False

            messagebox.showerror(
                "FluidSynth",
                f"Не удалось загрузить FluidSynth:\n\n{e}"
            )

    # =========================================================
    # UI
    # =========================================================

    def build_ui(self):

        top = tk.Frame(
            self.root
        )

        top.pack(
            fill="x",
            padx=5,
            pady=5
        )

        tk.Label(
            top,
            text="BPM:"
        ).pack(
            side="left"
        )

        tk.Spinbox(
            top,
            from_=30,
            to=300,
            textvariable=self.bpm,
            width=5
        ).pack(
            side="left",
            padx=5
        )

        tk.Button(
            top,
            text="▶ Play",
            command=self.play
        ).pack(
            side="left",
            padx=5
        )

        tk.Button(
            top,
            text="■ Stop",
            command=self.stop
        ).pack(
            side="left",
            padx=5
        )

        tk.Button(
            top,
            text="Save",
            command=self.save_project
        ).pack(
            side="left",
            padx=5
        )

        tk.Button(
            top,
            text="Open",
            command=self.open_project
        ).pack(
            side="left",
            padx=5
        )

        export_button = tk.Menubutton(
            top,
            text="Export",
            relief="raised"
        )

        export_menu = tk.Menu(
            export_button,
            tearoff=0
        )

        export_menu.add_command(
            label="Export WAV",
            command=lambda:
            self.export_audio("wav")
        )

        export_menu.add_command(
            label="Export MP3",
            command=lambda:
            self.export_audio("mp3")
        )

        export_menu.add_command(
            label="Export OGG",
            command=lambda:
            self.export_audio("ogg")
        )

        export_menu.add_command(
            label="Export FLAC",
            command=lambda:
            self.export_audio("flac")
        )

        export_menu.add_separator()

        export_menu.add_command(
            label="Export MIDI",
            command=self.export_midi
        )

        export_button["menu"] = export_menu

        export_button.pack(
            side="left",
            padx=5
        )

        # =====================================================
        # MAIN AREA
        # =====================================================

        main = tk.Frame(
            self.root
        )

        main.pack(
            fill="both",
            expand=True
        )

        # =====================================================
        # SECTIONS
        # =====================================================

        left = tk.Frame(
            main,
            width=230,
            relief="sunken",
            borderwidth=1
        )

        left.pack(
            side="left",
            fill="y"
        )

        tk.Label(
            left,
            text="SECTIONS",
            font=("Arial", 12, "bold")
        ).pack(
            pady=5
        )

        self.section_list = tk.Listbox(
            left,
            width=26,
            height=20
        )

        self.section_list.pack(
            fill="both",
            expand=True,
            padx=5
        )

        self.section_list.bind(
            "<<ListboxSelect>>",
            self.select_section
        )

        tk.Button(
            left,
            text="+ New Section",
            command=self.create_section
        ).pack(
            fill="x",
            padx=5,
            pady=3
        )

        tk.Button(
            left,
            text="Rename Section",
            command=self.rename_section
        ).pack(
            fill="x",
            padx=5,
            pady=3
        )

        tk.Button(
            left,
            text="Delete Section",
            command=self.delete_section
        ).pack(
            fill="x",
            padx=5,
            pady=3
        )

        tk.Button(
            left,
            text="Add Audio File",
            command=self.add_audio
        ).pack(
            fill="x",
            padx=5,
            pady=3
        )

        self.audio_label = tk.Label(
            left,
            text="Audio: none",
            wraplength=200
        )

        self.audio_label.pack(
            padx=5,
            pady=5
        )

        # =====================================================
        # PIANO ROLL
        # =====================================================

        center = tk.Frame(
            main
        )

        center.pack(
            side="left",
            fill="both",
            expand=True
        )

        instrument_frame = tk.Frame(
            center
        )

        instrument_frame.pack(
            fill="x"
        )

        tk.Label(
            instrument_frame,
            text="Instrument:"
        ).pack(
            side="left",
            padx=5
        )

        self.instrument_box = ttk.Combobox(
            instrument_frame,
            values=INSTRUMENTS,
            state="readonly",
            width=28
        )

        self.instrument_box.current(0)

        self.instrument_box.pack(
            side="left",
            padx=5,
            pady=5
        )

        self.instrument_box.bind(
            "<<ComboboxSelected>>",
            self.change_instrument
        )

        piano_frame = tk.Frame(
            center
        )

        piano_frame.pack(
            fill="both",
            expand=True
        )

        self.canvas = tk.Canvas(
            piano_frame,
            bg="#202020"
        )

        self.canvas.pack(
            fill="both",
            expand=True
        )

        hscroll = tk.Scrollbar(
            center,
            orient="horizontal",
            command=self.canvas.xview
        )

        hscroll.pack(
            fill="x"
        )

        self.canvas.configure(
            xscrollcommand=hscroll.set
        )

        self.canvas.bind(
            "<Button-1>",
            self.add_note
        )

        self.canvas.bind(
            "<Button-3>",
            self.remove_note
        )

        # =====================================================
        # PLAYLIST
        # =====================================================

        tk.Label(
            self.root,
            text="PLAYLIST / ARRANGEMENT",
            font=("Arial", 12, "bold")
        ).pack(
            pady=(5, 0)
        )

        playlist_frame = tk.Frame(
            self.root,
            height=180
        )

        playlist_frame.pack(
            fill="x",
            padx=5,
            pady=5
        )

        self.playlist_canvas = tk.Canvas(
            playlist_frame,
            height=150,
            bg="#151515"
        )

        self.playlist_canvas.pack(
            fill="both",
            expand=True
        )

        playlist_scroll = tk.Scrollbar(
            self.root,
            orient="horizontal",
            command=self.playlist_canvas.xview
        )

        playlist_scroll.pack(
            fill="x",
            padx=5
        )

        self.playlist_canvas.configure(
            xscrollcommand=playlist_scroll.set
        )

        self.playlist_canvas.bind(
            "<Button-1>",
            self.playlist_click
        )

        self.playlist_canvas.bind(
            "<Button-3>",
            self.playlist_right_click
        )

        tk.Button(
            self.root,
            text="Add Selected Section To Playlist",
            command=self.add_to_playlist
        ).pack(
            pady=3
        )

        self.status = tk.Label(
            self.root,
            text="Ready",
            anchor="w"
        )

        self.status.pack(
            fill="x",
            padx=5
        )

    # =========================================================
    # SECTIONS
    # =========================================================

    def create_section(self):

        self.section_counter += 1

        name = (
            f"Section "
            f"{self.section_counter}"
        )

        self.sections[name] = {
            "notes": [],
            "audio": None,
            "instrument": 0
        }

        self.current_section = name

        self.refresh_sections()

        self.select_current_section()

    def refresh_sections(self):

        self.section_list.delete(
            0,
            tk.END
        )

        for name in self.sections:

            self.section_list.insert(
                tk.END,
                name
            )

    def select_current_section(self):

        if not self.current_section:
            return

        names = list(
            self.sections.keys()
        )

        if self.current_section not in names:
            return

        index = names.index(
            self.current_section
        )

        self.section_list.selection_clear(
            0,
            tk.END
        )

        self.section_list.selection_set(
            index
        )

        self.section_list.see(
            index
        )

        self.load_current_section()

    def select_section(self, event=None):

        selection = (
            self.section_list.curselection()
        )

        if not selection:
            return

        names = list(
            self.sections.keys()
        )

        index = selection[0]

        if index >= len(names):
            return

        self.current_section = names[index]

        self.load_current_section()

    def load_current_section(self):

        if not self.current_section:
            return

        section = self.sections[
            self.current_section
        ]

        program = section.get(
            "instrument",
            0
        )

        self.instrument.set(
            program
        )

        self.instrument_box.current(
            program
        )

        audio = section.get(
            "audio"
        )

        if audio:

            self.audio_label.config(
                text=(
                    "Audio:\n"
                    + os.path.basename(audio)
                )
            )

        else:

            self.audio_label.config(
                text="Audio: none"
            )

        self.draw_piano()

    def rename_section(self):

        if not self.current_section:
            return

        popup = tk.Toplevel(
            self.root
        )

        popup.title(
            "Rename Section"
        )

        popup.geometry(
            "320x110"
        )

        entry = tk.Entry(
            popup
        )

        entry.pack(
            fill="x",
            padx=10,
            pady=10
        )

        entry.insert(
            0,
            self.current_section
        )

        def rename():

            new_name = entry.get().strip()

            if not new_name:
                return

            if (
                new_name != self.current_section
                and new_name in self.sections
            ):

                messagebox.showerror(
                    "Error",
                    "Такой Section уже существует."
                )

                return

            old_name = (
                self.current_section
            )

            data = self.sections.pop(
                old_name
            )

            self.sections[new_name] = data

            self.playlist = [
                new_name
                if x == old_name
                else x
                for x in self.playlist
            ]

            self.current_section = new_name

            popup.destroy()

            self.refresh_sections()

            self.select_current_section()

            self.draw_playlist()

        tk.Button(
            popup,
            text="Rename",
            command=rename
        ).pack()

    def delete_section(self):

        if len(self.sections) <= 1:

            messagebox.showinfo(
                "Sections",
                "Нельзя удалить последний Section."
            )

            return

        if not self.current_section:
            return

        answer = messagebox.askyesno(
            "Delete Section",
            f"Удалить {self.current_section}?"
        )

        if not answer:
            return

        name = self.current_section

        del self.sections[name]

        self.playlist = [
            x
            for x in self.playlist
            if x != name
        ]

        self.current_section = next(
            iter(self.sections)
        )

        self.refresh_sections()

        self.select_current_section()

        self.draw_playlist()

    # =========================================================
    # AUDIO
    # =========================================================

    def add_audio(self):

        if not self.current_section:
            return

        path = filedialog.askopenfilename(
            title="Choose audio file",
            filetypes=[
                (
                    "Audio files",
                    "*.wav *.mp3 *.ogg *.flac "
                    "*.aiff *.aac *.m4a"
                ),
                (
                    "All files",
                    "*.*"
                )
            ]
        )

        if not path:
            return

        self.sections[
            self.current_section
        ]["audio"] = path

        self.audio_label.config(
            text=(
                "Audio:\n"
                + os.path.basename(path)
            )
        )

        self.status.config(
            text=(
                "Audio added to "
                + self.current_section
            )
        )

    # =========================================================
    # PIANO ROLL
    # =========================================================

    def draw_piano(self):

        self.canvas.delete(
            "all"
        )

        width = (
            MAX_BEATS
            * CELL_W
        )

        height = (
            len(NOTES)
            * CELL_H
        )

        for beat in range(
            MAX_BEATS + 1
        ):

            x = beat * CELL_W

            color = (
                "#777777"
                if beat % 4 == 0
                else "#444444"
            )

            self.canvas.create_line(
                x,
                0,
                x,
                height,
                fill=color
            )

            if beat < MAX_BEATS:

                self.canvas.create_text(
                    x + 3,
                    3,
                    text=str(beat + 1),
                    anchor="nw",
                    fill="#aaaaaa"
                )

        for row, (name, pitch) in enumerate(
            NOTES
        ):

            y = row * CELL_H

            bg = (
                "#292929"
                if "#" in name
                else "#383838"
            )

            self.canvas.create_rectangle(
                0,
                y,
                width,
                y + CELL_H,
                fill=bg,
                outline="#151515"
            )

            self.canvas.create_text(
                4,
                y + CELL_H // 2,
                text=name,
                anchor="w",
                fill="white"
            )

        if not self.current_section:
            return

        notes = self.sections[
            self.current_section
        ]["notes"]

        for note in notes:

            row = next(
                (
                    i
                    for i, n in enumerate(NOTES)
                    if n[1] == note["pitch"]
                ),
                None
            )

            if row is None:
                continue

            x1 = (
                note["start"]
                * CELL_W
            )

            x2 = (
                note["start"]
                + note["length"]
            ) * CELL_W

            y1 = row * CELL_H
            y2 = y1 + CELL_H

            self.canvas.create_rectangle(
                x1,
                y1,
                x2,
                y2,
                fill="#4da6ff",
                outline="white"
            )

        self.canvas.configure(
            scrollregion=(
                0,
                0,
                width,
                height
            )
        )

    def add_note(self, event):

        if not self.current_section:
            return

        x = self.canvas.canvasx(
            event.x
        )

        y = self.canvas.canvasy(
            event.y
        )

        start = int(
            x // CELL_W
        )

        row = int(
            y // CELL_H
        )

        if (
            row < 0
            or row >= len(NOTES)
        ):
            return

        pitch = NOTES[row][1]

        notes = self.sections[
            self.current_section
        ]["notes"]

        for note in notes:

            if (
                note["start"] == start
                and note["pitch"] == pitch
            ):
                return

        notes.append({
            "start": start,
            "length": 1,
            "pitch": pitch
        })

        self.draw_piano()

    def remove_note(self, event):

        if not self.current_section:
            return

        x = self.canvas.canvasx(
            event.x
        )

        y = self.canvas.canvasy(
            event.y
        )

        start = int(
            x // CELL_W
        )

        row = int(
            y // CELL_H
        )

        if (
            row < 0
            or row >= len(NOTES)
        ):
            return

        pitch = NOTES[row][1]

        notes = self.sections[
            self.current_section
        ]["notes"]

        self.sections[
            self.current_section
        ]["notes"
        ] = [
            n
            for n in notes
            if not (
                n["start"] == start
                and n["pitch"] == pitch
            )
        ]

        self.draw_piano()

    # =========================================================
    # INSTRUMENT
    # =========================================================

    def change_instrument(
        self,
        event=None
    ):

        if not self.current_section:
            return

        program = (
            self.instrument_box.current()
        )

        self.instrument.set(
            program
        )

        self.sections[
            self.current_section
        ]["instrument"] = program

        if self.synth_ready:

            try:

                self.fs.program_select(
                    0,
                    self.sfid,
                    0,
                    program
                )

            except Exception:
                pass

    # =========================================================
    # PLAYLIST
    # =========================================================

    def add_to_playlist(self):

        if not self.current_section:
            return

        self.playlist.append(
            self.current_section
        )

        self.draw_playlist()

    def playlist_click(self, event):

        x = self.playlist_canvas.canvasx(
            event.x
        )

        index = int(
            x // 140
        )

        if (
            index >= 0
            and index < len(self.playlist)
        ):

            section = self.playlist[index]

            if section in self.sections:

                self.current_section = section

                self.select_current_section()

    def playlist_right_click(self, event):

        x = self.playlist_canvas.canvasx(
            event.x
        )

        index = int(
            x // 140
        )

        if (
            index >= 0
            and index < len(self.playlist)
        ):

            del self.playlist[index]

            self.draw_playlist()

    def draw_playlist(self):

        self.playlist_canvas.delete(
            "all"
        )

        block_width = 140

        for i, section in enumerate(
            self.playlist
        ):

            x = (
                i
                * block_width
            )

            self.playlist_canvas.create_rectangle(
                x + 2,
                10,
                x + block_width - 2,
                145,
                fill="#303030",
                outline="#6aa9ff"
            )

            self.playlist_canvas.create_text(
                x + block_width // 2,
                35,
                text=section,
                fill="white",
                font=(
                    "Arial",
                    10,
                    "bold"
                )
            )

            if section in self.sections:

                data = self.sections[
                    section
                ]

                note_count = len(
                    data["notes"]
                )

                text = (
                    f"Notes: "
                    f"{note_count}"
                )

                if data.get("audio"):
                    text += "\nAudio"

                self.playlist_canvas.create_text(
                    x + block_width // 2,
                    80,
                    text=text,
                    fill="#aaaaaa"
                )

        width = max(
            800,
            len(self.playlist)
            * block_width
        )

        self.playlist_canvas.configure(
            scrollregion=(
                0,
                0,
                width,
                160
            )
        )

    # =========================================================
    # PLAYBACK
    # =========================================================

    def play(self):

        if self.playing:
            return

        if not self.playlist:

            messagebox.showinfo(
                "Playlist",
                "Сначала добавь Section в Playlist."
            )

            return

        self.playing = True
        self.stop_requested = False

        threading.Thread(
            target=self.play_worker,
            daemon=True
        ).start()

    def play_worker(self):

        try:

            bpm = max(
                30,
                min(
                    300,
                    self.bpm.get()
                )
            )

            beat_time = (
                60.0 / bpm
            )

            for section_name in self.playlist:

                if self.stop_requested:
                    break

                if section_name not in self.sections:
                    continue

                section = self.sections[
                    section_name
                ]

                notes = sorted(
                    section["notes"],
                    key=lambda n:
                    n["start"]
                )

                self.root.after(
                    0,
                    lambda s=section_name:
                    self.status.config(
                        text=f"Playing {s}"
                    )
                )

                instrument = section.get(
                    "instrument",
                    0
                )

                if self.synth_ready:

                    self.fs.program_select(
                        0,
                        self.sfid,
                        0,
                        instrument
                    )

                current_beat = 0

                for note in notes:

                    if self.stop_requested:
                        break

                    wait = (
                        note["start"]
                        - current_beat
                    )

                    if wait > 0:

                        time.sleep(
                            wait
                            * beat_time
                        )

                    if self.stop_requested:
                        break

                    if self.synth_ready:

                        self.fs.noteon(
                            0,
                            note["pitch"],
                            100
                        )

                    time.sleep(
                        note["length"]
                        * beat_time
                    )

                    if self.synth_ready:

                        self.fs.noteoff(
                            0,
                            note["pitch"]
                        )

                    current_beat = (
                        note["start"]
                        + note["length"]
                    )

                section_length = 4

                if notes:

                    section_length = max(
                        4,
                        max(
                            n["start"]
                            + n["length"]
                            for n in notes
                        )
                    )

                remaining = (
                    section_length
                    - current_beat
                )

                if remaining > 0:

                    time.sleep(
                        remaining
                        * beat_time
                    )

        except Exception as e:

            self.root.after(
                0,
                lambda:
                messagebox.showerror(
                    "Playback error",
                    str(e)
                )
            )

        finally:

            self.playing = False

            self.root.after(
                0,
                lambda:
                self.status.config(
                    text="Ready"
                )
            )

    def stop(self):

        self.stop_requested = True

        if self.synth_ready:

            try:
                self.fs.all_notes_off(0)
            except Exception:
                pass

        self.playing = False

        self.status.config(
            text="Stopped"
        )

    # =========================================================
    # PROJECT SAVE
    # =========================================================

    def save_project(self):

        path = filedialog.asksaveasfilename(
            defaultextension=".scm",
            filetypes=[
                (
                    "SuperCoolMusicCreator",
                    "*.scm"
                )
            ]
        )

        if not path:
            return

        data = {
            "version": VERSION,
            "bpm": self.bpm.get(),
            "sections": self.sections,
            "playlist": self.playlist
        }

        try:

            with open(
                path,
                "w",
                encoding="utf-8"
            ) as f:

                json.dump(
                    data,
                    f,
                    indent=4,
                    ensure_ascii=False
                )

            self.status.config(
                text="Project saved"
            )

        except Exception as e:

            messagebox.showerror(
                "Save error",
                str(e)
            )

    # =========================================================
    # PROJECT OPEN
    # =========================================================

    def open_project(self):

        path = filedialog.askopenfilename(
            filetypes=[
                (
                    "SuperCoolMusicCreator",
                    "*.scm"
                ),
                (
                    "All files",
                    "*.*"
                )
            ]
        )

        if not path:
            return

        try:

            with open(
                path,
                "r",
                encoding="utf-8"
            ) as f:

                data = json.load(f)

            self.stop()

            self.bpm.set(
                data.get(
                    "bpm",
                    120
                )
            )

            self.sections = data.get(
                "sections",
                {}
            )

            self.playlist = data.get(
                "playlist",
                []
            )

            if not self.sections:

                self.section_counter = 0

                self.create_section()

            else:

                self.section_counter = len(
                    self.sections
                )

                self.current_section = next(
                    iter(self.sections)
                )

                self.refresh_sections()

                self.select_current_section()

            self.draw_playlist()

            self.status.config(
                text="Project opened"
            )

        except Exception as e:

            messagebox.showerror(
                "Open error",
                str(e)
            )

    # =========================================================
    # MIDI
    # =========================================================

    def vlq(self, value):

        buffer = [
            value & 0x7F
        ]

        value >>= 7

        while value:

            buffer.insert(
                0,
                (value & 0x7F) | 0x80
            )

            value >>= 7

        return bytes(buffer)

    def create_midi(self):

        events = []

        absolute_beat = 0

        for section_name in self.playlist:

            section = self.sections.get(
                section_name
            )

            if not section:
                continue

            notes = section["notes"]

            section_length = 4

            if notes:

                section_length = max(
                    4,
                    max(
                        n["start"]
                        + n["length"]
                        for n in notes
                    )
                )

            for note in notes:

                start = (
                    absolute_beat
                    + note["start"]
                ) * PPQ

                end = (
                    absolute_beat
                    + note["start"]
                    + note["length"]
                ) * PPQ

                events.append(
                    (
                        start,
                        1,
                        bytes([
                            0x90,
                            note["pitch"],
                            100
                        ])
                    )
                )

                events.append(
                    (
                        end,
                        0,
                        bytes([
                            0x80,
                            note["pitch"],
                            0
                        ])
                    )
                )

            absolute_beat += section_length

        events.sort(
            key=lambda x:
            (x[0], x[1])
        )

        track = bytearray()

        tempo = int(
            60000000
            / self.bpm.get()
        )

        track += self.vlq(0)

        track += bytes([
            0xFF,
            0x51,
            0x03
        ])

        track += tempo.to_bytes(
            3,
            "big"
        )

        current = 0

        for tick, _, event in events:

            track += self.vlq(
                tick - current
            )

            track += event

            current = tick

        track += self.vlq(0)

        track += bytes([
            0xFF,
            0x2F,
            0x00
        ])

        header = (
            b"MThd"
            + (6).to_bytes(
                4,
                "big"
            )
            + (0).to_bytes(
                2,
                "big"
            )
            + (1).to_bytes(
                2,
                "big"
            )
            + PPQ.to_bytes(
                2,
                "big"
            )
        )

        chunk = (
            b"MTrk"
            + len(track).to_bytes(
                4,
                "big"
            )
            + track
        )

        return header + chunk

    def export_midi(self):

        if not self.playlist:

            messagebox.showinfo(
                "MIDI",
                "Playlist пуст."
            )

            return

        path = filedialog.asksaveasfilename(
            defaultextension=".mid",
            filetypes=[
                (
                    "MIDI",
                    "*.mid"
                )
            ]
        )

        if not path:
            return

        try:

            midi = self.create_midi()

            with open(
                path,
                "wb"
            ) as f:

                f.write(midi)

            messagebox.showinfo(
                "MIDI",
                "MIDI exported!"
            )

        except Exception as e:

            messagebox.showerror(
                "MIDI error",
                str(e)
            )

    # =========================================================
    # AUDIO RENDER
    # =========================================================

    def render_audio(self):

        bpm = max(
            30,
            min(
                300,
                self.bpm.get()
            )
        )

        beat_seconds = (
            60.0 / bpm
        )

        total_beats = 0

        for section_name in self.playlist:

            section = self.sections.get(
                section_name
            )

            if not section:
                continue

            notes = section["notes"]

            length = 4

            if notes:

                length = max(
                    4,
                    max(
                        n["start"]
                        + n["length"]
                        for n in notes
                    )
                )

            total_beats += length

        if total_beats <= 0:
            total_beats = 4

        total_frames = int(
            (
                total_beats
                * beat_seconds
                + 1.0
            )
            * SAMPLE_RATE
        )

        synth = fluidsynth.Synth(
            samplerate=SAMPLE_RATE
        )

        synth.start()

        sf_path = os.path.join(
            os.path.dirname(
                os.path.abspath(__file__)
            ),
            SOUNDFONT
        )

        sfid = synth.sfload(
            sf_path
        )

        events = []

        absolute_beat = 0

        for section_name in self.playlist:

            section = self.sections.get(
                section_name
            )

            if not section:
                continue

            notes = section["notes"]

            instrument = section.get(
                "instrument",
                0
            )

            section_length = 4

            if notes:

                section_length = max(
                    4,
                    max(
                        n["start"]
                        + n["length"]
                        for n in notes
                    )
                )

            for note in notes:

                start_frame = int(
                    (
                        absolute_beat
                        + note["start"]
                    )
                    * beat_seconds
                    * SAMPLE_RATE
                )

                end_frame = int(
                    (
                        absolute_beat
                        + note["start"]
                        + note["length"]
                    )
                    * beat_seconds
                    * SAMPLE_RATE
                )

                events.append(
                    (
                        start_frame,
                        1,
                        note["pitch"],
                        instrument
                    )
                )

                events.append(
                    (
                        end_frame,
                        0,
                        note["pitch"],
                        instrument
                    )
                )

            absolute_beat += section_length

        events.sort(
            key=lambda x:
            (x[0], x[1])
        )

        audio = []

        current_frame = 0

        try:

            for (
                frame,
                event_type,
                pitch,
                instrument
            ) in events:

                if frame > current_frame:

                    count = (
                        frame
                        - current_frame
                    )

                    samples = synth.get_samples(
                        count
                    )

                    audio.extend(
                        samples
                    )

                    current_frame = frame

                synth.program_select(
                    0,
                    sfid,
                    0,
                    instrument
                )

                if event_type == 1:

                    synth.noteon(
                        0,
                        pitch,
                        100
                    )

                else:

                    synth.noteoff(
                        0,
                        pitch
                    )

            remaining = (
                total_frames
                - current_frame
            )

            if remaining > 0:

                samples = synth.get_samples(
                    remaining
                )

                audio.extend(
                    samples
                )

        finally:

            try:
                synth.all_notes_off(0)
            except Exception:
                pass

            try:
                synth.delete()
            except Exception:
                pass

        return audio

    # =========================================================
    # WRITE WAV
    # =========================================================

    def write_wav(
        self,
        path,
        samples
    ):

        """
        FluidSynth get_samples() returns
        stereo interleaved samples:

        L R L R L R ...

        pyfluidsynth versions can return
        either integer or float samples.

        This function converts them safely
        to signed 16-bit PCM.
        """

        frames = bytearray()

        for sample in samples:

            if isinstance(
                sample,
                float
            ):

                # Float range: -1.0 ... 1.0

                sample = max(
                    -1.0,
                    min(
                        1.0,
                        sample
                    )
                )

                value = int(
                    sample
                    * 32767.0
                )

            else:

                value = int(
                    sample
                )

                value = max(
                    -32768,
                    min(
                        32767,
                        value
                    )
                )

            frames += struct.pack(
                "<h",
                value
            )

        with wave.open(
            path,
            "wb"
        ) as wav:

            wav.setnchannels(2)

            wav.setsampwidth(2)

            wav.setframerate(
                SAMPLE_RATE
            )

            wav.writeframes(
                frames
            )

    # =========================================================
    # AUDIO EXPORT
    # =========================================================

    def export_audio(
        self,
        fmt
    ):

        if not self.playlist:

            messagebox.showinfo(
                "Export",
                "Playlist пуст."
            )

            return

        path = filedialog.asksaveasfilename(
            defaultextension=(
                "."
                + fmt
            ),
            filetypes=[
                (
                    fmt.upper(),
                    "*."
                    + fmt
                )
            ]
        )

        if not path:
            return

        threading.Thread(
            target=self.export_worker,
            args=(
                path,
                fmt
            ),
            daemon=True
        ).start()

    def export_worker(
        self,
        path,
        fmt
    ):

        temp_path = (
            os.path.splitext(path)[0]
            + "_temp.wav"
        )

        try:

            self.root.after(
                0,
                lambda:
                self.status.config(
                    text=(
                        "Rendering "
                        + fmt.upper()
                        + "..."
                    )
                )
            )

            samples = self.render_audio()

            if fmt == "wav":

                self.write_wav(
                    path,
                    samples
                )

            else:

                self.write_wav(
                    temp_path,
                    samples
                )

                ffmpeg = shutil.which(
                    "ffmpeg"
                )

                if not ffmpeg:

                    raise RuntimeError(
                        "FFmpeg не найден в PATH.\n"
                        "WAV работает без FFmpeg."
                    )

                result = subprocess.run(
                    [
                        ffmpeg,
                        "-y",
                        "-i",
                        temp_path,
                        path
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )

                if result.returncode != 0:

                    raise RuntimeError(
                        result.stderr[
                            -3000:
                        ]
                    )

                if os.path.exists(
                    temp_path
                ):

                    os.remove(
                        temp_path
                    )

            self.root.after(
                0,
                lambda:
                self.status.config(
                    text="Export complete"
                )
            )

            self.root.after(
                0,
                lambda:
                messagebox.showinfo(
                    "Export",
                    "Файл успешно создан:\n\n"
                    + path
                )
            )

        except Exception as e:

            try:

                if os.path.exists(
                    temp_path
                ):

                    os.remove(
                        temp_path
                    )

            except Exception:
                pass

            self.root.after(
                0,
                lambda:
                self.status.config(
                    text="Export failed"
                )
            )

            self.root.after(
                0,
                lambda:
                messagebox.showerror(
                    "Export error",
                    str(e)
                )
            )

    # =========================================================
    # CLOSE
    # =========================================================

    def close(self):

        self.stop()

        try:

            if self.fs:
                self.fs.delete()

        except Exception:
            pass

        self.root.destroy()


# =============================================================
# START
# =============================================================

if __name__ == "__main__":

    root = tk.Tk()

    app = SuperCoolMusicCreator(
        root
    )

    root.mainloop()