python SuperCoolMusicCreator.py
pause