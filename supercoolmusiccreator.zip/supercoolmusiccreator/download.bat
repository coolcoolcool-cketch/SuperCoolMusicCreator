pip install pyfluidsynth
del download.bat